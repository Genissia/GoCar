package com.example.gocar.helper;

public class Cars {
    private String Model_Name;
    private int ProductionYear;
    private double Latitude;
    private double Longitude;
    private int Fuel;

    public Cars(String Model_Name, int ProductionYear, double Latitude, double Longitude, int Fuel) {
        this.Model_Name = Model_Name;
        this.ProductionYear = ProductionYear;
        this.Latitude = Latitude;
        this.Longitude = Longitude;
        this.Fuel = Fuel;
    }
    public String getModel_Name(){
        return this.Model_Name;
    }
    public int getProductionYear(){
        return this.ProductionYear;
    }
    public double getLatitude(){
        return this.Latitude;
    }
    public double getLongitude(){
        return this.Longitude;
    }
    public int getFuel(){
        return this.Fuel;
    }


}
